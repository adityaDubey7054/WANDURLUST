# ProjectMain


1. Download code zip file
2. After downloading, extract the file
3. Open the extracted folder in vs code
4. Then, in the VS Code terminal, type npm i
5. again type node app.js
